using System.Diagnostics;
using Intekmont.Web.Models;
using Intekmont.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace Intekmont.Web.Controllers;

public sealed class HomeController(ILeadStore leadStore, ILeadNotifier leadNotifier, ILogger<HomeController> logger) : Controller
{
    [HttpGet("/")]
    public IActionResult Index() => View(new LeadRequest());

    [HttpGet("/services")]
    public IActionResult Services() => View();

    [HttpGet("/solutions")]
    public IActionResult Solutions() => View();

    [HttpGet("/about")]
    public IActionResult About() => View();

    [HttpGet("/portfolio")]
    public IActionResult Portfolio() => View();

    [HttpGet("/business")]
    public IActionResult Business() => View();

    [HttpGet("/contacts")]
    public IActionResult Contacts() => View();

    [HttpPost("/send-request")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SendLead(LeadRequest model, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(model.Website))
            return Redirect("/?sent=1#contact");

        if (!ModelState.IsValid)
        {
            TempData["LeadError"] = "Проверьте заполнение формы.";
            return View("Index", model);
        }

        var lead = new LeadRecord(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            model.Name.Trim(),
            model.Phone.Trim(),
            model.Service.Trim(),
            model.Message.Trim());

        await leadStore.SaveAsync(lead, cancellationToken);
        logger.LogInformation("New website lead {LeadId}", lead.Id);

        var emailSent = await leadNotifier.TryNotifyAsync(lead, cancellationToken);

        TempData["LeadSuccess"] = "Заявка принята. Мы свяжемся с вами по указанному номеру.";

        if (!emailSent)
            logger.LogWarning("Lead {LeadId} was saved, but email notification was not sent.", lead.Id);

        return Redirect("/?sent=1#contact");
    }

    [HttpGet("/privacy")]
    public IActionResult Privacy() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() => View(new ErrorViewModel
    {
        RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
    });
}
