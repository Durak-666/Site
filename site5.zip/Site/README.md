# INTECMONT Site

ASP.NET Core MVC, .NET 9.

## Запуск

```bash
dotnet run --project Site/Site.csproj
```

В Codespaces сайт работает на порту `3000`.

## Основные файлы

- `Views/Home/Index.cshtml` — главная;
- `Views/Home/Services.cshtml` — услуги;
- `Views/Home/Portfolio.cshtml` — работы / решения;
- `Views/Home/About.cshtml` — о компании;
- `Views/Home/Business.cshtml` — B2B;
- `Views/Home/Contacts.cshtml` — контакты;
- `wwwroot/css/site.css` — весь дизайн и адаптив;
- `wwwroot/js/site.js` — меню и анимации;
- `appsettings.json` — контакты и SMTP.

Пароль от почты нельзя коммитить в публичный GitHub-репозиторий. Для боевого запуска его следует хранить в секретах/переменных окружения.
