(() => {
    const header = document.querySelector('[data-header]');
    const menuButton = document.querySelector('[data-menu-button]');
    const mobileMenu = document.querySelector('[data-mobile-menu]');
    const fab = document.querySelector('[data-telegram-fab]');
    const contactSection = document.querySelector('[data-contact-section]');
    const footer = document.querySelector('[data-footer]');
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const updateHeader = () => header?.classList.toggle('scrolled', window.scrollY > 18);
    updateHeader();
    window.addEventListener('scroll', updateHeader, { passive: true });

    if (menuButton && mobileMenu) {
        const closeMenu = () => {
            menuButton.setAttribute('aria-expanded', 'false');
            mobileMenu.classList.remove('open');
            document.body.classList.remove('menu-open');
        };

        menuButton.addEventListener('click', () => {
            const willOpen = menuButton.getAttribute('aria-expanded') !== 'true';
            menuButton.setAttribute('aria-expanded', String(willOpen));
            mobileMenu.classList.toggle('open', willOpen);
            document.body.classList.toggle('menu-open', willOpen);
        });

        mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
        window.addEventListener('resize', () => {
            if (window.innerWidth > 940) closeMenu();
        });
    }

    if (reduceMotion) {
        document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
    } else {
        const revealObserver = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -28px' });

        document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));
    }

    if (fab && (contactSection || footer)) {
        const visibility = new Map();
        const setFabState = () => {
            const shouldHide = [...visibility.values()].some(Boolean);
            fab.classList.toggle('is-hidden', shouldHide);
        };
        const overlapObserver = new IntersectionObserver(entries => {
            entries.forEach(entry => visibility.set(entry.target, entry.isIntersecting));
            setFabState();
        }, { threshold: 0.08 });
        if (contactSection) overlapObserver.observe(contactSection);
        if (footer) overlapObserver.observe(footer);
    }

    const phone = document.querySelector('input[name="Phone"]');
    phone?.addEventListener('input', () => {
        phone.value = phone.value.replace(/[^0-9+()\-\s]/g, '').slice(0, 24);
    });

    if (new URLSearchParams(location.search).has('sent')) {
        history.replaceState({}, '', `${location.pathname}#contact`);
    }
})();
