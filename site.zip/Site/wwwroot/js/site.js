(() => {
    const header = document.querySelector('[data-header]');
    const button = document.querySelector('[data-menu-button]');
    const menu = document.querySelector('[data-mobile-menu]');
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const onScroll = () => header?.classList.toggle('scrolled', window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    if (button && menu) {
        button.addEventListener('click', () => {
            const open = button.getAttribute('aria-expanded') === 'true';
            button.setAttribute('aria-expanded', String(!open));
            menu.classList.toggle('open', !open);
            document.body.classList.toggle('menu-open', !open);
        });

        menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
            button.setAttribute('aria-expanded', 'false');
            menu.classList.remove('open');
            document.body.classList.remove('menu-open');
        }));
    }

    if (!prefersReducedMotion) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px' });

        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

        const scene = document.querySelector('.tech-scene');
        scene?.addEventListener('pointermove', (event) => {
            const rect = scene.getBoundingClientRect();
            const x = (event.clientX - rect.left) / rect.width - 0.5;
            const y = (event.clientY - rect.top) / rect.height - 0.5;
            scene.style.transform = `perspective(1200px) rotateY(${x * 4}deg) rotateX(${y * -4}deg)`;
        });
        scene?.addEventListener('pointerleave', () => {
            scene.style.transform = 'perspective(1200px) rotateY(0deg) rotateX(0deg)';
        });
    } else {
        document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
    }

    const phone = document.querySelector('input[name="Phone"]');
    phone?.addEventListener('input', () => {
        phone.value = phone.value.replace(/[^0-9+()\-\s]/g, '').slice(0, 24);
    });

    if (new URLSearchParams(location.search).has('sent')) {
        history.replaceState({}, '', `${location.pathname}#contact`);
    }
})();
