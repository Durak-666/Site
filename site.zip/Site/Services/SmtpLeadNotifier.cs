using System.Net;
using System.Net.Mail;
using System.Text;
using Intekmont.Web.Models;
using Intekmont.Web.Options;
using Microsoft.Extensions.Options;

namespace Intekmont.Web.Services;

public sealed class SmtpLeadNotifier(IOptions<SmtpOptions> smtpOptions, ILogger<SmtpLeadNotifier> logger) : ILeadNotifier
{
    public async Task<bool> TryNotifyAsync(LeadRecord lead, CancellationToken cancellationToken = default)
    {
        var smtp = smtpOptions.Value;
        if (!smtp.Enabled)
        {
            logger.LogInformation("SMTP notifications are disabled.");
            return false;
        }

        if (string.IsNullOrWhiteSpace(smtp.Host) ||
            string.IsNullOrWhiteSpace(smtp.Username) ||
            string.IsNullOrWhiteSpace(smtp.Password) ||
            string.IsNullOrWhiteSpace(smtp.FromEmail) ||
            string.IsNullOrWhiteSpace(smtp.ToEmail))
        {
            logger.LogWarning("SMTP is enabled but configuration is incomplete.");
            return false;
        }

        using var message = new MailMessage
        {
            From = new MailAddress(smtp.FromEmail, smtp.FromName, Encoding.UTF8),
            Subject = $"Новая заявка с сайта INTECMONT · {lead.Service}",
            BodyEncoding = Encoding.UTF8,
            SubjectEncoding = Encoding.UTF8,
            IsBodyHtml = true,
            Body = BuildBody(lead)
        };

        message.To.Add(new MailAddress(smtp.ToEmail));
        message.ReplyToList.Add(new MailAddress(smtp.FromEmail, smtp.FromName, Encoding.UTF8));

        using var client = new SmtpClient(smtp.Host, smtp.Port)
        {
            Credentials = new NetworkCredential(smtp.Username, smtp.Password),
            EnableSsl = smtp.UseSsl,
            DeliveryMethod = SmtpDeliveryMethod.Network
        };

        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            await client.SendMailAsync(message);
            logger.LogInformation("Lead notification sent for {LeadId}", lead.Id);
            return true;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send lead notification for {LeadId}", lead.Id);
            return false;
        }
    }

    private static string BuildBody(LeadRecord lead)
    {
        string esc(string? s) => System.Net.WebUtility.HtmlEncode(s ?? string.Empty);

        return $"""
        <div style="font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;padding:24px;color:#0d1b2a;">
          <div style="max-width:640px;margin:0 auto;background:#ffffff;border:1px solid #dde5f0;border-radius:18px;overflow:hidden;">
            <div style="background:#050b16;padding:20px 24px;color:#ffffff;">
              <div style="font-size:12px;letter-spacing:.18em;opacity:.72;margin-bottom:8px;">INTECMONT · WEBSITE LEAD</div>
              <div style="font-size:24px;font-weight:700;">Новая заявка с сайта</div>
            </div>
            <div style="padding:24px;">
              <table style="width:100%;border-collapse:collapse;">
                <tr><td style="padding:10px 0;color:#6b7687;width:180px;">Дата</td><td style="padding:10px 0;font-weight:600;">{esc(lead.CreatedAtUtc.ToLocalTime().ToString("dd.MM.yyyy HH:mm"))}</td></tr>
                <tr><td style="padding:10px 0;color:#6b7687;">Имя</td><td style="padding:10px 0;font-weight:600;">{esc(lead.Name)}</td></tr>
                <tr><td style="padding:10px 0;color:#6b7687;">Телефон</td><td style="padding:10px 0;font-weight:600;">{esc(lead.Phone)}</td></tr>
                <tr><td style="padding:10px 0;color:#6b7687;">Услуга</td><td style="padding:10px 0;font-weight:600;">{esc(lead.Service)}</td></tr>
                <tr><td style="padding:10px 0;color:#6b7687;vertical-align:top;">Описание</td><td style="padding:10px 0;font-weight:600;white-space:pre-line;">{esc(lead.Message)}</td></tr>
                <tr><td style="padding:10px 0;color:#6b7687;">ID заявки</td><td style="padding:10px 0;font-family:Consolas,monospace;">{lead.Id}</td></tr>
              </table>
            </div>
          </div>
        </div>
        """;
    }
}
