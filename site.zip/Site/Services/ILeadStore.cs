using Intekmont.Web.Models;

namespace Intekmont.Web.Services;

public interface ILeadStore
{
    Task SaveAsync(LeadRecord lead, CancellationToken cancellationToken = default);
}
