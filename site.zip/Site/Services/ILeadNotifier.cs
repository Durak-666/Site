using Intekmont.Web.Models;

namespace Intekmont.Web.Services;

public interface ILeadNotifier
{
    Task<bool> TryNotifyAsync(LeadRecord lead, CancellationToken cancellationToken = default);
}
