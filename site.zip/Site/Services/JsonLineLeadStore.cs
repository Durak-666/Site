using System.Text.Json;
using Intekmont.Web.Models;

namespace Intekmont.Web.Services;

public sealed class JsonLineLeadStore(IWebHostEnvironment environment, ILogger<JsonLineLeadStore> logger) : ILeadStore
{
    private readonly SemaphoreSlim _lock = new(1, 1);
    private readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web);

    public async Task SaveAsync(LeadRecord lead, CancellationToken cancellationToken = default)
    {
        var directory = Path.Combine(environment.ContentRootPath, "App_Data");
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, "leads.jsonl");
        var line = JsonSerializer.Serialize(lead, _jsonOptions) + Environment.NewLine;

        await _lock.WaitAsync(cancellationToken);
        try
        {
            await File.AppendAllTextAsync(path, line, cancellationToken);
        }
        finally
        {
            _lock.Release();
        }

        logger.LogInformation("Saved lead {LeadId} for service {Service}", lead.Id, lead.Service);
    }
}
