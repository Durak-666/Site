using System.ComponentModel.DataAnnotations;

namespace Intekmont.Web.Models;

public sealed class LeadRequest
{
    [Required(ErrorMessage = "Укажите имя")]
    [StringLength(80, MinimumLength = 2, ErrorMessage = "Имя должно содержать от 2 до 80 символов")]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Укажите телефон")]
    [StringLength(40, MinimumLength = 6, ErrorMessage = "Проверьте номер телефона")]
    public string Phone { get; set; } = "";

    [StringLength(100)]
    public string Service { get; set; } = "";

    [StringLength(1500, ErrorMessage = "Описание слишком длинное")]
    public string Message { get; set; } = "";

    [Range(typeof(bool), "true", "true", ErrorMessage = "Необходимо согласие на обработку данных")]
    public bool Consent { get; set; }

    // Honeypot: обычный пользователь это поле не видит.
    public string? Website { get; set; }
}
