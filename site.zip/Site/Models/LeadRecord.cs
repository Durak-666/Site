namespace Intekmont.Web.Models;

public sealed record LeadRecord(
    Guid Id,
    DateTimeOffset CreatedAtUtc,
    string Name,
    string Phone,
    string Service,
    string Message);
