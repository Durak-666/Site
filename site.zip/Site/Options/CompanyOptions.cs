namespace Intekmont.Web.Options;

public sealed class CompanyOptions
{
    public string Name { get; set; } = "INTECMONT";
    public string Tagline { get; set; } = "Инженерные системы и техническое обслуживание";
    public string Region { get; set; } = "Москва и Московская область";
    public string PhoneDisplay { get; set; } = "+7 (965) 439-30-88";
    public string PhoneHref { get; set; } = "tel:+79654393088";
    public string Email { get; set; } = "intecmont@gmail.com";
    public string TelegramUrl { get; set; } = "https://t.me/InTecMont";
    public string TelegramHandle { get; set; } = "@InTecMont";
    public string WhatsAppUrl { get; set; } = "";
    public string WorkHours { get; set; } = "Ежедневно, 09:00–20:00";
}
