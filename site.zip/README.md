# INTECMONT site

## Быстрый запуск в GitHub Codespaces

1. Открой репозиторий в Codespaces.
2. Дождись завершения подготовки среды.
3. В терминале выполни:

```bash
dotnet run --project Site/Site.csproj
```

Сайт слушает порт 3000. Codespaces должен автоматически пробросить порт и открыть сайт.

Если браузер не открылся автоматически:
- открой вкладку **Ports / Порты**;
- найди порт **3000**;
- нажми **Open in Browser**.

## Контакты
- Телефон: +7 (965) 439-30-88
- Email: intecmont@gmail.com
- Telegram: @InTecMont

## Отправка заявок на Gmail

Форма сохраняет каждую заявку локально в `Site/App_Data/leads.jsonl`.

Для отправки писем на `intecmont@gmail.com` открой `Site/appsettings.json`, раздел `Smtp`:
- включи `Enabled`;
- укажи Gmail App Password в `Password`.

Не добавляй реальный App Password в публичный GitHub-репозиторий. Для боевого сайта его нужно хранить в секретах/переменных окружения.
